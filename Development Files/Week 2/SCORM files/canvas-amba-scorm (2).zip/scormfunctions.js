var SCORM_API=null,SCORM_initialized=false,pageStartTime=new Date();
function findAPI(w){while((!w.API)&&(w.parent)&&(w.parent!=w)){w=w.parent;}return w.API;}
function getAPI(){try{return findAPI(window)||findAPI(window.opener);}catch(e){return null;}}
function SCORM_Initialize(){SCORM_API=getAPI();if(SCORM_API){var ok=SCORM_API.LMSInitialize("");SCORM_initialized=(ok==="true");if(SCORM_initialized){SCORM_API.LMSSetValue("cmi.core.lesson_status","incomplete");SCORM_API.LMSCommit("");}}}
function SCORM_SetSessionTime(){if(SCORM_API&&SCORM_initialized){var sec=Math.round((new Date()-pageStartTime)/1000);var h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;var t=(h<10?"0":"")+h+":"+(m<10?"0":"")+m+":"+(s<10?"0":"")+s;SCORM_API.LMSSetValue("cmi.core.session_time",t);SCORM_API.LMSCommit("");}}
function SCORM_SetComplete(){if(SCORM_API&&SCORM_initialized){SCORM_API.LMSSetValue("cmi.core.lesson_status","completed");SCORM_SetSessionTime();SCORM_API.LMSCommit("");}}
var maxScroll=0;function track(){var d=document.documentElement;var p=(window.pageYOffset/(d.scrollHeight-window.innerHeight))*100;if(p>maxScroll){maxScroll=p;if(maxScroll>90){SCORM_SetComplete();window.removeEventListener('scroll',track);}}}
window.addEventListener('load',function(){SCORM_Initialize();window.addEventListener('scroll',track);});
setInterval(function(){try{SCORM_SetSessionTime();}catch(e){}},60000);
window.addEventListener('beforeunload',function(){try{if(SCORM_API&&SCORM_initialized){SCORM_SetSessionTime();SCORM_API.LMSCommit("");SCORM_API.LMSFinish("");}}catch(e){}});